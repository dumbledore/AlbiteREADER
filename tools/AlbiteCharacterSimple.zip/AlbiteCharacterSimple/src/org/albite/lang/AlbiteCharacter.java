/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.albite.lang;

/**
 *
 * @author albus
 */
public class AlbiteCharacter {

    public static final byte
	UNASSIGNED		= 0,
	UPPERCASE_LETTER	= 1,
	LOWERCASE_LETTER	= 2,
	TITLECASE_LETTER	= 3,
	MODIFIER_LETTER		= 4,
	OTHER_LETTER		= 5,
	NON_SPACING_MARK	= 6,
	ENCLOSING_MARK		= 7,
	COMBINING_SPACING_MARK	= 8,
	DECIMAL_DIGIT_NUMBER	= 9,
	LETTER_NUMBER		= 10,
	OTHER_NUMBER		= 11,
	SPACE_SEPARATOR		= 12,
	LINE_SEPARATOR		= 13,
	PARAGRAPH_SEPARATOR	= 14,
	CONTROL			= 15,
	FORMAT			= 16,
	PRIVATE_USE		= 18,
	SURROGATE		= 19,
	DASH_PUNCTUATION	= 20,
	START_PUNCTUATION	= 21,
	END_PUNCTUATION		= 22,
	CONNECTOR_PUNCTUATION	= 23,
	OTHER_PUNCTUATION	= 24,
	MATH_SYMBOL		= 25,
	CURRENCY_SYMBOL		= 26,
	MODIFIER_SYMBOL		= 27,
	OTHER_SYMBOL		= 28;

    public static int getType(final char ch) {
        return LOWERCASE_LETTER;
    }

    public static boolean isLetterOrDigit(final char ch) {
        return true;
    }

    public static boolean isLetter(final char ch) {
        return true;
    }

    public static boolean isDigit(final char ch) {
        return Character.isDigit(ch);
    }

    public static char toLowerCase(final char ch) {
        return ch;
    }

    public static char[] toLowerCase(final char[] ch) {
        return new String(ch).toLowerCase().toCharArray();
    }

    public static String toLowerCase(final String s) {
        return s.toLowerCase();
    }
}