/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.microedition.midlet.*;

/**
 * @author albus
 */
public class Midlet extends MIDlet {
    public void startApp() {
        Saver.save();
        notifyDestroyed();
    }

    public void pauseApp() {
    }

    public void destroyApp(boolean unconditional) {
    }
}
